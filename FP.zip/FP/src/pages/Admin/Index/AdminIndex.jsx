import React from 'react'

const AdminIndex = () => {
  return (
    <div>Dashboard</div>
  )
}

export default AdminIndex