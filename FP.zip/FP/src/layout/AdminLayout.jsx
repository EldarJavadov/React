import React from "react";
import Sidebar from "../pages/Admin/Components/Sidebar/Sidebar";

const AdminLayout = (props) => {
  return (
    <div>
      <Sidebar />
      <main className="container my-5">
        {props.children}
      </main>
    </div>
  );
};

export default AdminLayout;
