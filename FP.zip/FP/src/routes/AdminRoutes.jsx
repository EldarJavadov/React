import React from 'react'
import { Route, Routes } from 'react-router-dom'
import AdminLayout from '../layout/AdminLayout'
import AdminIndex from '../pages/Admin/Index/AdminIndex'
import Products from '../pages/Admin/Products/Products'

const AdminRoutes = () => {
  return (
    <AdminLayout>
        <Routes>
            <Route path='/manage' element={<AdminIndex />} />
            <Route path='/manage/products' element={<Products />} />
        </Routes>          
    </AdminLayout>
  )
}

export default AdminRoutes