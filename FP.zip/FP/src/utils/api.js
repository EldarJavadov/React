const apiUrl = {
    baseUrl: 'https://dummyjson.com/',
    productsUrl: 'https://dummyjson.com/products',
    categoryUrl: 'https://dummyjson.com/products/categories'
}

export default apiUrl