const apiUrl = {
    baseUrl: 'https://dummyjson.com/',
    productsUrl: 'https://dummyjson.com/products'
}

export default apiUrl