import axios from "axios"
import { createContext, useEffect, useState } from "react"
import apiUrl from "../utils/api"

export const ProductContext = createContext()

export const ProductProvider = ({ children }) => {
    const [product, setProduct] = useState([])

    useEffect(() => {
        const getProducts = async () => {
          await axios.get(`${apiUrl.productsUrl}`)
          .then(response => setProduct(response.data.products))
          .catch(error => console.log(error))
        }
    
        getProducts()
    }, [product])



    return (
        <ProductContext.Provider value={{ product }}>
            {children}
        </ProductContext.Provider>
    )
}