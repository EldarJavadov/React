import React, { useContext, useState } from 'react'
import Card from '../../components/dynamic/Card/Card'
import SearchCategory from '../../components/dynamic/SearchCaregory/SearchCategory'
import { ProductContext } from '../../context/ProductContext'


const Products = () => {
  const {products} = useContext(ProductContext)
console.log(products);
  return (
    <div>
        <SearchCategory />
        {products && products.map((item, index) => {
          return (
            <Card data={item} key={item.id} />
          )
          })
        }
    </div>
  )
}

export default Products