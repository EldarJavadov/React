import React from 'react'
import SearchCategory from '../../components/dynamic/SearchCaregory/SearchCategory'

const Products = () => {
  return (
    <div>
        <SearchCategory />
    </div>
  )
}

export default Products