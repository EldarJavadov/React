import axios from 'axios'
import React, { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import apiUrl from '../../utils/api'
import SwiperCore, { Navigation, Pagination, Thumbs } from 'swiper';
import { Swiper, SwiperSlide } from 'swiper/react'
import 'swiper/swiper-bundle.css';
import { Spinner } from 'react-bootstrap';
import './details.css'

const ProductDetails = () => {
  const {id} = useParams()
  const [product, setProduct] = useState(0)

  useEffect(() => {
    const getProduct = async () => {
      await axios.get(`${apiUrl.productsUrl}/${id}`)
      .then(response => setProduct(response.data))
      .catch(error => console.log(error))
    }

    getProduct()
  }, [])

  const { brand, category, description, price, rating, stock, discountPercentage, images } = product

 
  // Swiper thumbs
  {images && images.length > 0 && (
    images.map((image, index) => (
      <SwiperSlide key={index}>
        <img src={image} alt={`Thumbnail ${index + 1}`} />
      </SwiperSlide>
    ))
  )}
  

  return (
    <div className='row'>
      <div className="col-md-4">
        <Swiper
            spaceBetween={10}
            className="mb-3"
          >
            {images.map((image, index) => (
              <SwiperSlide key={index}>
                <img src={image} alt={`Image ${index + 1}`} />
              </SwiperSlide>
            ))}
        </Swiper>
      </div>
      <div className="col-md-6">
        <div className="card">
          <div className="card-body">
              <p className="card-text mb-2 text-muted text-capitalize">{category}</p>
              <h5 className="card-title">{brand}</h5>
              <p className="card-text">{description}</p>
              <p className="card-text">Qiyməti: {price} azn</p>
              <br />
          </div>
        </div>
      </div>
    </div>
  )
}

export default ProductDetails