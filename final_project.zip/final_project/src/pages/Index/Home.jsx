import React from 'react'
import { useEffect } from 'react'
import { useState } from 'react'
import axios from 'axios'
import Categories from '../../components/dynamic/Categories/Categories'

const Home = () => {
  const [products, setProducts] = useState([])

  useEffect(() => {
    const getProducts = async () => {
      await axios.get('https://dummyjson.com/products')
      .then(response => setProducts(response.data))
      .catch(error => console.log(error))
    }

    getProducts()
  }, [])

  return (
    <div className='col-lg-3'>
      <Categories />
    </div>
  )
}

export default Home