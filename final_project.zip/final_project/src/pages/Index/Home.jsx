import React from 'react'
import { useEffect } from 'react'
import { useState } from 'react'
import axios from 'axios'

const Home = () => {
  const [products, setProducts] = useState([])

  useEffect(() => {
    const getProducts = async () => {
      await axios.get('https://dummyjson.com/products')
      .then(response => console.log(response))
      .catch(error => console.log(error))
    }

    getProducts()
  }, [])

  return (
    <div className='container'>
      <div className='row'>

      </div>
    </div>
  )
}

export default Home