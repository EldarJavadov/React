import React from 'react'
import { useEffect, useState } from 'react'
import axios from 'axios'
import Categories from '../../components/dynamic/Categories/Categories'
import Card from '../../components/dynamic/Card/Card'
import { Swiper, SwiperSlide } from 'swiper/react'
import 'swiper/css'
import apiUrl from '../../utils/api'

const Home = () => {
  const [products, setProducts] = useState([])

  useEffect(() => {
    const getProducts = async () => {
      await axios.get(`${apiUrl.productsUrl}`)
      .then(response => setProducts(response.data.products))
      .catch(error => console.log(error))
    }

    getProducts()
  }, [])

  

  return (
    <div>
      <div className='row bg-light rounded-2 p-2'>
        <div className='col-lg-3'>
          <Categories />
        </div>
        <div className='col-lg-9'>
          <Swiper slidesPerView={3} >
            <SwiperSlide>
              <img src="https://i.dummyjson.com/data/products/1/1.jpg" alt="" />
            </SwiperSlide>
            <SwiperSlide>
              <img src="https://i.dummyjson.com/data/products/1/2.jpg" alt="" />
            </SwiperSlide>
          </Swiper>
        </div>
      </div>
      <div className='row gy-3 my-4 p-0'>
          <h3 className='bg-light fw-bold my-4 p-2 rounded-2'>Məhsullar</h3>
          {
            products && products.map(item => {
              return (
                <Card data={item} key={item.id} />
              )
            })
          }
          
      </div>

    </div>

    
  )
}

export default Home