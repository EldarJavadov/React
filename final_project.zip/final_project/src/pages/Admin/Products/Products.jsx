import axios from 'axios'
import React, { useEffect, useState } from 'react'
import apiUrl from '../../../utils/api'

const Products = () => {
  const [products, setProducts] = useState([])

  useEffect(() => {
    const getProducts = async () => {
      await axios.get(`${apiUrl.productsUrl}`)
      .then(response => console.log(response))
      .catch(error => console.log(error))
    }

    getProducts()
  },[])
  return (
    <div>Admin Products</div>
  )
}

export default Products