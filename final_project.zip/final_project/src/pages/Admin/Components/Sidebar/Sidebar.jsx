import React from 'react'
import './sidebar.css'
import { NavLink } from 'react-router-dom'

const LeftSidebar = () => {
  return (
    <aside>
      <ul>
        <li>
          <NavLink to='/manage'>Dashboard</NavLink>
        </li>
        <li>
          <NavLink to='/manage/products'>Products</NavLink>
        </li>
      </ul>
    </aside>
  )
}

export default LeftSidebar