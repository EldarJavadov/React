import axios from "axios"
import React, { useEffect, useState } from "react"
import apiUrl from "../../../utils/api"
import "./categories.css"
import Spinner from 'react-bootstrap/Spinner';


const Categories = () => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [category, setCategory] = useState([]);

  useEffect(() => {
    const getCategory = async () => {
      await axios
        .get(`${apiUrl.productsUrl}/categories`)
        .then((response) => setCategory(response.data))
        .catch((error) => console.log(error))
    };

    getCategory()
  }, [])

  const toggleCategories = () => {
    setIsExpanded(!isExpanded)
  }


  if (category.length === 0) {
    return (
        <div className='text-center'>
            <Spinner animation="border" variant="secondary" />
        </div>
    )
  }

  return (
    <div>
      <h4 className="p-0">Bütün kateqoriyalar</h4>
      <ul className="list-group categoryList border" style={{ maxHeight: isExpanded ? "none" : "370px" }}>
        {category && category.map((item, index) => {
            return (
                <li key={index} className="list-group-item border-0 text-capitalize" >
                    <a href={`/products/category/${item}`}> {item} </a>
                </li>
            );
          })}
      </ul>
      <li className="show-more border rounded-2" onClick={toggleCategories}>
        {isExpanded ? (
          <p className="m-0">
            Daha az <span>-</span>
          </p>
        ) : (
          <p className="m-0">
            Daha çox <span>+</span>
          </p>
        )}
      </li>
    </div>
  );
};

export default Categories;
