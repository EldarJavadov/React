import axios from 'axios'
import React, { useEffect, useState } from 'react'
import apiUrl from '../../../utils/api'

const Categories = () => {
    const [category, setCategory] = useState([])

    useEffect(() => {
        const getCategory = async () => {
            await axios.get(`${apiUrl.productsUrl}/categories`)
            .then(response => setCategory(response.data))
            .catch(error => console.log(error))
        }

        getCategory()
    },[])
    
  return (
    <div>
        <h4 className='m-0 p-0'>Bütün kateqoriyalar</h4>
        <ul className='list-group'>
            {
                category && category.map((item, index) => {
                    return (
                        <li key={index} className='list-group-item border-0 text-capitalize'>{item}</li>
                    )
                })
            }
        </ul>
    </div>
  )
}

export default Categories