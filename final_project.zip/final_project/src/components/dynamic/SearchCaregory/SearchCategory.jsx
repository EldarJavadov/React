import React from 'react'

const SearchCategory = () => {
  return (
    <div>
      <input type="text" className='form-control' placeholder='Axtar...' />
    </div>
  )
}

export default SearchCategory