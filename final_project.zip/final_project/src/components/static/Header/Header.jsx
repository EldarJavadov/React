import React from 'react'
import { Link, NavLink } from 'react-router-dom'
import '../Header/header.css'

const Header = () => {
  return (
    <header>
        <div className="container py-3 border-bottom">
            <div className="row">
                <div className="col-lg-2">
                    <div className="logo">
                        <Link to='/' >FinalProj</Link>
                    </div>
                </div>
                <div className="col-lg-10 text-end">
                    <nav>
                        <NavLink to='/' >Home</NavLink>
                        <NavLink to='/products' >Products</NavLink>
                    </nav>
                </div>
            </div>
        </div>
    </header>
  )
}

export default Header