import React from 'react'
import {Routes, Route} from 'react-router-dom'
import Layout from '../layout/Layout'
import Home from '../pages/Index/Home'
import ProductDetails from '../pages/ProductDetails/ProductDetails'

const PublicRoutes = () => {
  return (
    <Layout>
        <Routes>
            <Route path='/' element={<Home />} />
            <Route path='/products' element={<ProductDetails />} />
        </Routes>
    </Layout>
  )
}

export default PublicRoutes