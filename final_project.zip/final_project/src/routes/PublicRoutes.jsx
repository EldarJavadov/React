import React from 'react'
import {Routes, Route} from 'react-router-dom'
import Layout from '../layout/Layout'
import Home from '../pages/Index/Home'
import ProductDetails from '../pages/ProductDetails/ProductDetails'
import Products from '../pages/Products/Products'

const PublicRoutes = () => {
  return (
    <Layout>
        <Routes>
            <Route path='/' element={<Home />} />
            <Route path='/products' element={<Products />} />
            <Route path='/products/:id' element={<ProductDetails />} />
        </Routes>
    </Layout>
  )
}

export default PublicRoutes